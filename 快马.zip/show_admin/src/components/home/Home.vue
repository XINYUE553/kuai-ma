<template>
<el-container>
  <el-header height="72px" direction="horizontal">
    <el-row>
  <el-col :span="8" ><img src="@/assets/logo.png" alt=""></el-col>
  <el-col :span="8"><h1>电商后台管理系统</h1></el-col>
  <el-col :span="8"><a href="javascript:;" @click="log" >退出</a><span>欢迎您星耀会员</span></el-col>
</el-row>
  </el-header>
  <el-container>
    <el-aside width="210px">
 <el-menu
      :router="true"
      default-active="2"
      class="el-menu-vertical-demo"
      @open="handleOpen"
      @close="handleClose"
      background-color="#545c64"
      text-color="#fff"
      active-text-color="#ffd04b"
      >
      <el-submenu index="1">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span>用户管理</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="/users"><i class="el-icon-menu"></i> 用户列表</el-menu-item>
        </el-menu-item-group>
      </el-submenu>

     <el-submenu index="2">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span>权限管理</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="/power"><i class="el-icon-menu"></i>角色列表</el-menu-item>
        </el-menu-item-group>
        <el-menu-item-group>
          <el-menu-item index="/rbac"><i class="el-icon-menu"></i>权限列表</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      
      <el-submenu index="3">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span>商品管理</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="3-1"><i class="el-icon-menu"></i>选项2</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-submenu index="4">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span>订单管理</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="4-1"><i class="el-icon-menu"></i>选项2</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-submenu index="5">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span>数据统计</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="5-1"><i class="el-icon-menu"></i>选项2</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
    </el-menu>
    </el-aside>

    <el-main>
       <router-view></router-view>
    </el-main>
  </el-container>
</el-container>
</template>
<script>
export default {
   methods:{
      log() {
        this.$confirm('退出后台, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          localStorage.removeItem('token')
          this.$router.push('/login')
        }).catch(() => {
         
          });          
        },
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      }
      
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.el-col-8{
  height: 72px;
  line-height: 72px;
}
.el-col-8 img{
  float: left;
}
.el-col-8 h1{
  line-height: 72px;
  color: #fff;
  font-size: 46px;
}
.el-col-8 span{
  font-weight: 900;
  font-size: 20px;
  float:right;
}
.el-col-8 a{
  font-weight: 900;
  font-size: 20px;
  color: #ce9f05fb;
  float: right;
}
.el-container{
  height: 100%;
}

  .el-header, .el-footer {
    background-color: #B3C0D1;
    color: #333;
    text-align: center;
    line-height: 60px;
  }
  
  .el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
    line-height: 200px;
  }
  
  .el-main {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 160px;
  }
  
  body > .el-container {
    margin-bottom: 40px;
  }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
  .el-aside{
    text-align: left;
  }
  .el-menu-item-group__title{
    height: 0px;
  }
</style>