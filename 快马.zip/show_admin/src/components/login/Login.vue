<template>
  <div class="hello" >
    <el-row type="flex" class="row-bg"  align="middle" justify="space-around">
      <el-col :xs="12" :sm="10" :md="8" :lg="6" :xl="4" class="login-content">
        <div class="grid-content bg-purple" >
          <el-form
            :model="ruleForm"
            :rules="rules"
            ref="ruleForm"
            label-width="100px"
            class="demo-ruleForm"
            label-position="top"
            
          >
            <el-form-item label="用户名：" prop="username">
              <el-input v-model="ruleForm.username"></el-input>
            </el-form-item>
            <el-form-item label="密码：" prop="password">
              <el-input v-model="ruleForm.password"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submitForm('ruleForm')">登录</el-button>
              <el-button @click="resetForm('ruleForm')">重置</el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      ruleForm: {
        username: "admin",
        password: "123456"
      },
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { min: 2, max: 50, message: "至少2个字符", trigger: "blur" }
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 6, max: 30, message: "至少6个字符", trigger: "blur" }
        ]
      }
    };
  },
  methods: {
      login(){
         this.http.post("/login",this.ruleForm)
         .then((res)=>{
           let {data,meta}=res.data
            console.log(data)
            if(meta.status==200){
              localStorage.setItem('token', data.token)
              this.$router.push("/home")
            }else{
                this.$message({
                    type:'error',
                    message:meta.msg,
                    duration:1000
                })
            }
         })
      },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
        //   alert("submit!");
        this.login()
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.hello,.row-bg{
    height: 100%;
   
}
.row-bg{
     background-color: green;
}
.grid-content{
    min-width: 300px;
    padding: 30px;
    background-color: #fff;
    border-radius: 30px;
}
</style>