<template>
<div>
  <el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
  <el-breadcrumb-item>活动管理</el-breadcrumb-item>
  <el-breadcrumb-item>活动列表</el-breadcrumb-item>

</el-breadcrumb>
  <el-table
    :data="tableList"
    style="width: 100%"
    stripe
    >
    <el-table-column type="expand">
      <template slot-scope="props">
        <el-row v-if="props.row.children.length === 0">
          <el-col>暂无权限，请分配</el-col>
        </el-row>
        <!-- props.row.children 一级菜单 -->
        <el-row v-else class="rights-level1" v-for="level1 in props.row.children" :key="level1.id">
          <!-- 一级菜单的名称 -->
          <el-col :span="4">
            <el-tag closable>
              {{ level1.authName }}
            </el-tag>
            <i class="el-icon-arrow-right"></i>
          </el-col>

          <el-col :span="20">
            <el-row  class="rights-level2" v-for="level2 in level1.children" :key="level2.id">
              <!-- 二级菜单的名称 -->
              <el-col :span="4">
                <el-tag
                  closable
                  type="success">
                  {{ level2.authName }}
                </el-tag>
                <i class="el-icon-arrow-right"></i>
              </el-col>

              <el-col :span="20">
                <!-- 三级菜单的名称 -->
                <el-tag
                  v-for="level3 in level2.children"
                  :key="level3.id"
                  closable
                  type="warning">
                  {{ level3.authName }}
                </el-tag>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </template>
    </el-table-column>
    <el-table-column
      type="index"
      :index="indexMer"
      width="80px" >
    </el-table-column>
    <el-table-column
      label="角色名称"
      prop="roleName"
       width="180px">
    </el-table-column>
    <el-table-column
      label="描述"
      prop="roleDesc"
      >
    </el-table-column>
    <el-table-column
      label="操作"
      prop="desc"
        min-width="280px">
      <template slot-scope="scope">
      <el-button type="primary" icon="el-icon-edit" @click="showRoleEditDialog(scope.row)"></el-button>
      <el-button type="primary" icon="el-icon-delete" @click="sanc(scope.row.id)"></el-button>
        <el-button type="success" plain icon="el-icon-check" @click="showAssignRightsDialog(scope.row)">分配权限</el-button>
     </template>
    </el-table-column>
  </el-table>




   <el-dialog title="编辑角色" :visible.sync="roleEditDialog">
    <el-form ref="roleEditForm" :model="roleEditForm" label-width="120px" label-position="right">
      <el-form-item label="角色名称" prop="roleName">
        <el-input v-model="roleEditForm.roleName" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="角色描述	" prop="roleDesc">
        <el-input v-model="roleEditForm.roleDesc" auto-complete="off"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="roleEditDialog = false">取 消</el-button>
      <el-button type="primary" @click="editRole">确 定</el-button>
    </div>
  </el-dialog>


  <el-dialog title="分配权限" :visible.sync="assignRightsDialog">
    <!-- 树形权限菜单 -->
    <el-tree
      :data="rightsTreeData"
      show-checkbox
      default-expand-all
      node-key="id"
      ref="rightsTree"
      highlight-current
      :props="defaultProps">
    </el-tree>

    <div slot="footer" class="dialog-footer">
      <el-button @click="assignRightsDialog = false">取 消</el-button>
      <el-button type="primary" @click="setRoleRights">确 定</el-button>
    </div>
  </el-dialog>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        tableList: [],

         roleEditDialog: false,
           roleEditForm: {
           roleName: '',
           roleDesc: '',
           id: -1
          },
      assignRightsDialog: false,

      // 树形权限数据
      rightsTreeData: [],
      defaultProps: {
        // 通过哪个对象来表示当前节点的子节点
        // children: 'children',
        // 指定页面中节点名称使用数据中的哪个属性
        label: 'authName'
      },

      // 当前选中角色id
      curSelectedRoleId: -1
      }
    },
    created(){
      this. getRolesList()
    },
    methods:{
      async  getRolesList(){
        let res=await this.http.get('/roles')
        let {data,meta}=res.data
        if(meta.status===200){
          this.tableList=data
        }
      },
      indexMer(index){
        return index
      },


      sanc(id){
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.sancId(id)
          
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })          
        })
     
      },

      async sancId(id){
        let res=await this.http.delete(`/roles/${id}`)
        let {data,meta}=res.data
        if(meta.status===200){
          this.getRolesList()
          this.$message({
            type:'success',
            message:meta.msg
          })
        }
      },



     showRoleEditDialog (role) {
      this.roleEditDialog = true
      this.roleEditForm.roleName = role.roleName
      this.roleEditForm.roleDesc = role.roleDesc
      this.roleEditForm.id = role.id
    },
      async editRole () {
      const { id, roleName, roleDesc } = this.roleEditForm
      const res = await this.http.put(`roles/${id}`, {
        roleName,
        roleDesc
      })
      const { meta } = res.data
      if (meta.status === 200) {
        this.roleEditDialog = false
        this.getRolesList()
      }
    },




    showAssignRightsDialog (role) {
      this.curSelectedRoleId = role.id

      this.getAllRights(role)
    },

    // 获取到全部权限列表
    async getAllRights (role) {
      const res = await this.http.get('rights/tree')
      const { meta, data } = res.data
      if (meta.status === 200) {
        this.rightsTreeData = data
        this.assignRightsDialog = true

        this.$nextTick(() => {
          const level3Ids = []
          role.children.forEach(level1 => {
            level1.children.forEach(level2 => {
              level2.children.forEach(level3 => {
                level3Ids.push(level3.id)
              })
            })
          })

          // 设置默认选中
          this.$refs.rightsTree.setCheckedKeys(level3Ids)
        })
      }
    },

    // 设置角色权限
    async setRoleRights () {

      const checkedRights = this.$refs.rightsTree.getCheckedKeys()
      const checkedHalfRights = this.$refs.rightsTree.getHalfCheckedKeys()
      const allCheckedRights = [...checkedRights, ...checkedHalfRights]
      const res = await this.http.post(`/roles/${this.curSelectedRoleId}/rights`, {
        rids: allCheckedRights.join(',')
      })

      const { meta } = res.data

      if (meta.status === 200) {
        this.assignRightsDialog = false
        this.getRolesList()
      }
    }



    }
  }
</script>

<style>
  .demo-table-expand {
    font-size: 0;
  }
  .demo-table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }
.el-breadcrumb {
    font-size: 14px;
    line-height: 48px;
    height: 48px;
}
.el-table thead {
    color: #909399;
    font-weight: 500;
    line-height: 50px;
}
.el-table td, .el-table th{
  line-height: 50px;
}
.el-dialog__title{
  float: left;
}
.dialog-footer{
  height: 102px;
}
.el-dialog__body{
  padding-bottom: 0px;
}
</style>
