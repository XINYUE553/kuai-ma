<template>
  <div class="hello">
      <el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
  <el-breadcrumb-item>权限管理</el-breadcrumb-item>
  <el-breadcrumb-item>权限列表</el-breadcrumb-item>
</el-breadcrumb>
<template>
  <el-table :data="tableData" style="width: 100%"  >
    <el-table-column type="index" class="aa">
    </el-table-column>
    <el-table-column prop="authName" label="权限名称" width="180">
   </el-table-column>
      <el-table-column prop="path" label="路径"  width="180">
    </el-table-column>
    <el-table-column prop="level" label="层级">
      <template slot-scope="scope">
        <span v-if="scope.row.level === '0'">一级</span>
        <span v-else-if="scope.row.level === '1'">二级</span>
        <span v-else>三级</span>
      </template>
    </el-table-column>
      </el-table>
     </template>
  </div>
</template>
<script>
 export default {
    data() {
      return {
        tableData: [],
      }
      
    },
    created() {
        this.getlist()
      },
    methods: {
      async getlist(){
          let res=await this.http.get('rights/list')
          let {data,meta}=res.data
          if(meta.status===200){
              this.tableData=data
          }
      }
    }
  };
</script>


<style >
.el-table thead{

    line-height: 20px;
}

</style>
