<template>
  <div >
<el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
  <el-breadcrumb-item>用户管理</el-breadcrumb-item>
  <el-breadcrumb-item>用户列表</el-breadcrumb-item>
</el-breadcrumb>
<div style="margin-top:5px;margin-bottom:49px;">
  <el-input placeholder="请输入用户名" v-model="queryStr" class="input-with-select">
    <el-button slot="append" icon="el-icon-search"  @click="queryUserList"></el-button>
    
  </el-input>
  <el-button type="success" plain class="bu" @click="showUserAddDialog">添加用户</el-button>
</div>

 <el-table :data="userList" style="width: 100%;" class="dfdaf">
   
    <el-table-column label="姓名"  width="210" prop="username">
      </el-table-column>
    <el-table-column label="邮箱"  width="230" prop="email">
      </el-table-column>
    <el-table-column label="电话"  width="200" prop="mobile">
      </el-table-column>
    <el-table-column label="用户状态"  width="230" prop="mg_state">
       <template slot-scope="scope">
         <el-switch v-model="scope.row.mg_state" @change="chansur(scope.row.id,scope.row.mg_state)"></el-switch>
      </template>
     
    
    </el-table-column>
  
    <el-table-column label="操作" prop="address" >
        <template slot-scope="scope">
      <el-button type="primary" icon="el-icon-edit"  @click="showUserEditDailog(scope.row)"></el-button>
      <el-button type="primary" icon="el-icon-delete" @click="delUserById(scope.row.id)"></el-button>
        <el-button type="success" plain icon="el-icon-check">成功按钮</el-button>
     </template>
    </el-table-column>
  </el-table>
  <el-pagination
  background
  layout="prev, pager, next"
  :total="total"
  :page-size="3"
  :current-page.sync="curPage"
  @current-change="changePage">
</el-pagination>

<el-dialog title="添加用户" :visible.sync="userAddDialog" @close="closeUserAddDialog" class="tj">
      <el-form :model="userAddForm" :rules="userAddRules" ref="userAddForm">
        <el-form-item prop="username" label="用户名" label-width="120px">
          <el-input v-model="userAddForm.username" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item prop="password" label="密码" label-width="120px">
          <el-input v-model="userAddForm.password" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item prop="email" label="邮箱" label-width="120px">
          <el-input v-model="userAddForm.email" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item prop="mobile" label="手机" label-width="120px">
          <el-input v-model="userAddForm.mobile" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="userAddDialog = false" class="buta">取 消</el-button>
        <el-button type="primary" @click="addUser" class="butb">确 定</el-button>
      </div>
    </el-dialog>



    <el-dialog title="编辑用户" :visible.sync="userEditDialog" @close="closeUserEditDialog">
      <el-form :model="userEditForm" :rules="userEditRules" ref="userEditForm">
        <el-form-item prop="username" label="用户名" label-width="120px">
          <el-input disabled :value="userEditForm.username"></el-input>
        </el-form-item>
        <el-form-item prop="email" label="邮箱" label-width="120px">
          <el-input v-model="userEditForm.email" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item prop="mobile" label="手机" label-width="120px">
          <el-input v-model="userEditForm.mobile" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="userEditDialog = false" class="buta">取 消</el-button>
        <el-button type="primary" @click="editUser" class="butb">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>

export default {
  created(){
    this.getUserList();
    },
     data() {
      return {
       value: false,
      userList:[],
      total:0,
      pageSize:1,
      curPage:0,
      queryStr:'',
      userAddDialog: false,
      userAddForm: {
        username: '',
        password: '',
        email: '',
        mobile: ''
      },
      userAddRules: {
        username: [
          { required: true, message: '用户名为必填项', trigger: 'blur' },
          {
            min: 3,
            max: 6,
            message: '用户名长度在 3 到 6 个字符',
            trigger: 'blur'
          }
        ],
        password: [
          { required: true, message: '密码为必填项', trigger: 'blur' },
          {
            min: 3,
            max: 6,
            message: '密码长度在 3 到 6 个字符',
            trigger: 'blur'
          }
        ]
      },



      // 控制编辑用户对话框的展示和隐藏
      userEditDialog: false,
      userEditForm: {
        id: -1,
        username: '',
        email: '',
        mobile: ''
      },
      userEditRules: {
        mobile: [
          {
            pattern: /^(0|86|17951)?(13[0-9]|15[012356789]|166|17[3678]|18[0-9]|14[57])[0-9]{8}$/,
            message: '手机号码格式不正确',
            // 如果需要在值改变或者失去焦点的时候，都触发验证，可以传递两个
            // trigger: 'change, blur'

            // 当前值改变，就会触发
            trigger: 'change'
          }
        ]
      }
      }
    
    },











    methods: {

    async getUserList(curPage=1){
      let res= await this.http.get("/users",{
        params:{
          query:""||this.queryStr,
          pagenum:curPage,
          pagesize:3
        }
       
      })
      let {data, meta}=res.data
      if(meta.status===200){
        this.userList=data.users
        this.total=data.total
        this.curPage=data.pagenum
      }
      
    },
    changePage(curPage){
      this.getUserList(curPage)
    },
    queryUserList(){
      this.curPage=1;
      this.getUserList();
    },
      async chansur(id,state){
       let res=await this.http.put(`/users/${id}/state/${state}`)
      },
     showUserAddDialog() {
      this.userAddDialog = true
    },
      closeUserAddDialog() {
    // 关闭对话框重置表单
      this.$refs.userAddForm.resetFields()
    },
    // 添加用户
    addUser() {
      this.$refs.userAddForm.validate(valid => {
        if (valid) {
          this.http.post('/users', this.userAddForm).then(res => {
            const { meta } = res.data
            if (meta.status === 201) {
              // 1 关闭对话框
              // 2 重置表单(只要关闭对话框，就会自动触发对话框的关闭事件来重置表单)
              this.userAddDialog = false

              // 3 重新获取列表数据
              this.getUserList()
              // this.curPage = 1
            }
          })
        } else {
          // console.log('验证失败')
          return false
        }
      })
    },




    // 根据用户id删除用户
    delUserById(id) {
      // console.log(id)
      this.$confirm('确认删除该用户吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.http.delete(`users/${id}`).then(res => {
            // console.log(res)
            const { meta } = res.data
            if (meta.status === 200) {
              this.$message({
                type: 'success',
                message: meta.msg
              })

              // this.getUserList()
              // this.curPage = 1

              const index = this.userList.findIndex(item => item.id === id)
              this.userList.splice(index, 1)
              const totalPage = Math.ceil(this.userList.length / this.pageSize)
              if (this.curPage > totalPage) {
                this.getUserList(--this.curPage)
              }
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },



   // 展示编辑对话框
    showUserEditDailog(curUser) {
      // console.log(curUser)
      // 先获取到当前用户的数据
      // 数据交给 userEditForm 后，就会展示在编辑对话框中
      for (const key in this.userEditForm) {
        this.userEditForm[key] = curUser[key]
      }

      // 打开用户编辑对话框
      this.userEditDialog = true
    },

    // 关闭用户编辑对话框
    closeUserEditDialog() {
      this.$refs.userEditForm.resetFields()
    },

    // 点击确定按钮，修改用户数据
    editUser() {
      this.$refs.userEditForm.validate(valid => {
        if (valid) {
          const { id, email, mobile } = this.userEditForm
          // console.log('表单验证成功')
          this.http.put(`/users/${id}`, {email, mobile })
            .then(res => {
              // console.log(res)
              const { data, meta } = res.data
              if (meta.status === 200) {
                // 更新该用户的数据
                const editUser = this.userList.find(item => item.id === id)
                editUser.email = data.email
                editUser.mobile = data.mobile

                // 关闭对话
                this.userEditDialog = false
              }
            })
        } else {
          // console.log('表单验证失败')
          return false
        }
      })
    }
  }
}
</script>









































<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.el-breadcrumb{
  height: 34px;
  line-height: 34px;
  font-size: 16px;
  background-color: #cfcfd6cc;
}
.el-input{
    width: 100px;
    height: 40px;
    float: left;
}
.demo-form-inline{
    height: 40px;
}
.el-input__inner{
    float: left;
}
.el-form-item{
    height: 40px;
    float: left;
}
.el-button--primary{
    float: left;
    height: 42px;
    margin-right: 40px;
}
.is-plain{
    float: left;
    height: 42px;
}
.dfdaf{
  line-height: 50px;
}
.el-input[data-v-f5554e7e]{
  width: 280px;
}
.bu{
  margin-left: 30px;
  height: 40px;
}
.el-button--primary[data-v-f5554e7e]{
 margin-right: 10px;
}
.el-main[data-v-74b1de62]{
  line-height: 300px;
}
.el-dialog__footer{
      height: 278px;
}

  /deep/ .el-dialog__header{
    line-height: 50px;
    text-align: left;
  }
 /deep/  .el-dialog__body{
   height: 200px;
 }
/deep/ .el-dialog__footer{
  height: 100px;
      padding: 27px 52px 32px;
}
 .buta{
   float: right;
 }
 .butb{
   float: right;
   height: 40px;
   margin-right: 35px;
 }
</style>