import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/login/Login'
import Home from '@/components/home/Home'
import Users from '@/components/users/Users'
import Rbac from '@/components/rbac/Rbac'
import Power from '@/components/power/Power'

Vue.use(Router)

let router= new Router({
  mode: 'history',
  routes: [
    
    {
      path: '/login',
      name: 'Login',
      component: Login
    },
    {
      path: '/home',
      name: 'Home',
      component: Home,
      children:[
        {path:'/users',component:Users},
      
        {path:'/rbac',component:Rbac},
        {path:'/power',component:Power}
       
     ]
    }
  ]
})
router.beforeEach((to,from,next)=>{
if(to.path=='/login'){
  next()
}else{
  let token=localStorage.getItem('token')
  if(token){
    next()
  }else{
    next('/login')
  }
}
})

export default router